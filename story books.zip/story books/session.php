<?php

if(isset($_SESSION["matricule"])){
   $matricule_sav = $_SESSION["matricule"];
    //Information Etudiant
    $check = "SELECT * FROM etudiants WHERE matricule ='$matricule_sav'";
    $result = mysqli_query($connection, $check);// execution requet check
    $nombre = mysqli_num_rows($result);// nombre de resultat
    $row = mysqli_fetch_assoc($result);// sauv information des champs de la table dans row
    $uid = $row['id'];
    $username = $row['nom'];
    $matricule = $row['matricule'];
    $date_post = $row['date_poste'];
    $userimage = $row['image'];
    $classe = $row['classe'];
    $usergenre = $row['genre'];

    // echo 'WELCOME!!! '.$nom.'<br>';

}else{
    header('Location: login.php');
    
}

?>