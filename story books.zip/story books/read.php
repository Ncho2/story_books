<?php
session_start();
include("connexion/connexion.php");
include 'session.php';



  
?>

        <meta charset="utf-8" />
        <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
        <link rel="icon" type="image/png" href="./assets/img/favicon.png">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>
            Ajouter une Histoire
        </title>
        <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
        <!-- CSS Files -->
        <link href="css/material-kit.css?v=2.0.7" rel="stylesheet" />
        <!-- summernote independences -->

   
    <link rel="stylesheet" href="css/style.css">

  </head>
  <body class="index-page sidebar-collapse">
    <?php include'include/topbar.php'?>

    <div class="page-header header-filter clear-filter purple-filter" data-parallax="true" style="background-image: url('images/bg_profile.jpg'); height:250px">
        <div class="container">
       
            <div class="col-md-8 ml-auto mr-auto">
                <div class="brand">
                    <h1>Lire une histoire.</h1>
                 </div>
            </div>
       
        </div>
    </div>

    <div class="main main-raised">
        <div class="section section-basic">
             <div class="container mx-5">
                       
            

                    <div style="margin-top: 90px; margin-right:300px;">

                    <?php
                                  //  transfert des données à la page de lecture à travers "Id"

                                  include("connexion/connexion.php");
                                    if (isset($_POST['read_btn'])) {
                                        # code...
                                        $id=$_POST['read_id'];
                                        
                                        
                                        $query = "SELECT * FROM tablehistoire WHERE id='$id' ";
                                        $query_run = mysqli_query($connection, $query);
                                        
                                        foreach($query_run as $row)
                                        {
                                            ?>

                              
                                
                        <div class="card mb-3" style="max-width: 540px;">
                            <div class="row g-0">
                                <div class="col-md-4">
                                <img src="admin/<?php echo $row['image']; ?>" class="img-fluid rounded-start" alt="...">
                                </div>
                                <div class="col-md-8">
                                <div class="card-body">
                                <h5 class="card-title" ><?php echo $row['titre'] ?></h5>
                                <p class="card-text">Auteur : <span><?php echo $row['idadmin'] ?></span></p>
                                <p class="card-text">Publié le : <small class="text-muted"><?php echo $row['date_pub'] ?></small></p>
                            </div>
                            </div>
                        </div>
                        </div>

                          <div class="scroll-div mb-5">
                                <div class="scroll-object p-3 text-justify">
                                <?php echo $row['text_histoire'] ?>
                                </div>
                        </div>
                      
                        <?php
                          }
                            }

                      ?>
                                
                    </div>

            
        
            </div>
            <div class="text-center" style="margin-top: 60px;">
            <a href="index.php" class="btn btn-default  " role="button" aria-disabled="true">Retour</a>
            </div>
        </div>
    </div>
   
<!-- footer -->
      
<?php include'include/footer.php'?>

 <!--   Core JS Files   -->
 <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/popper.min.js" type="text/javascript"></script>
  <script src="js/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="js/moment.min.js"></script>
  <!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
  <script src="js/bootstrap-datetimepicker.js" type="text/javascript"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="js/nouislider.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="js/material-kit.js?v=2.0.7" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      materialKit.initFormExtendedDatetimepickers();

      // Sliders Init
      materialKit.initSliders();
    });


    function scrollToDownload() {
      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }
  </script>
               

    <script src="js/bootstrap.bundle.js"></script>
   

      
  </body>
</html>
