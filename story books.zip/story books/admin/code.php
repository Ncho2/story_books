<?php
session_start();
// include'security.php';
require_once("connexion/connexion.php");
include 'session.php';
    

//  PHASE D'ENREGISTREMENT DES UTILISATEURS (ELEVES)

if(isset($_POST['savebtn']))
{
        
        $username = $_POST['name'];
        $genre = $_POST['genre'];
        $age = $_POST['year'];
        $matricule = $_POST['matricule'];
        $classe = $_POST['classe'];
        $password = $_POST['password'];
        $cpassword = $_POST['confirmpassword'];
        $photo = $_FILES["file"]["name"];

        //  add file
        $target_dir = "upload/";//dossier de reception
        $target_file = $target_dir . basename($photo);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                // Check if image file is a actual image or fake image
        
        //     $check = getimagesize($_FILES["file"]["tmp_name"]);
        //     if($check !== false) {
        //         header('Location:users.php');
        //         echo "File is an image - " . $check["mime"] . ".";
        //     $uploadOk = 1;
        // } else {
        //     header('Location:users.php');
        //     $_SESSION['echec'] = "<span class='h6 text-center'>File is not an image.</span>";
        //     $uploadOk = 0;
        // }
        
            // Check file size
            if ($_FILES["file"]["size"] > 3000000) {
                header('Location:users.php');
                $_SESSION['echec'] = "<span class='h6 text-center'>Désolé, choisissez une photo < 3Mo.</span>";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" && $imageFileType != "jfif" ) {
                header('Location:users.php');
                $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</span>";
                $uploadOk = 0;
            }
            
       
                # code...
                //renomer l'image s'il  existe
                $temp = explode(".", $photo);
                $newfilename = round(microtime(true)) . '.' . end($temp);
                $finaldestination = $target_dir. $newfilename;
                //}
            

          
    
        if ($username && $genre && $age && $matricule  && $classe &&  $password && $cpassword) {

            if ($password === $cpassword) {

                  //Verification de l'existance d'un élève

                    $check = "SELECT * FROM etudiants WHERE matricule ='$matricule'";
                    $result = mysqli_query($connection, $check);
                    $nombre = mysqli_num_rows($result);

                    if ($nombre > 0) {
                        //insertion
                        $_SESSION['echec'] = "<span class='h6 text-center'>l'élève existe.</span>";
                  
                    header('Location:users.php');
                }
                else {
                # code...
                $query ="INSERT INTO etudiants (`nom`, `genre`, `dnaissance`, `classe`, `matricule`, `image`, `date_poste`, `motdepasse`) 
                VALUES ('$username','$genre','$age','$classe','$matricule','$finaldestination','$date_poste','$password')";
                $query_run = mysqli_query($connection, $query);

                if($query_run)
                {

                    // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    header('Location:users.php');
                    $_SESSION['echec'] = "<span class='h6 text-center'>Elève ajouté sans photo de profile.</span>";
                
                        
                        // if everything is ok, try to upload file
                        } else {
                            if (move_uploaded_file($_FILES["file"]["tmp_name"], "".$finaldestination)) {
                            echo "The file ". htmlspecialchars( basename( $photo)). " has been uploaded.";
                            } else {

                            $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, there was an error uploading your file.</span>";
                             header('Location:users.php');
                        
                            }
                        }

                    // echo "Enregistré";
                    $_SESSION['success'] = "<span class='h6 text-center'>Profil ajouté avec succès</span>";
                    header('Location: users.php');
                }
                else
                {
                    $_SESSION['echec'] = "<span class='h6 text-center'> Echec lors de l'ajout</span>";
                    header('Location: users.php'); 
                }
            }

            }else 
                    {
                        $_SESSION['echec'] = "<span class='h6 text-center'>Vérifiez que vos deux mots de passes sont identiques'</span>";
                       
                        header('Location: users.php'); 
                    }
                    
                    // autrement si tous les champs ne sont pas remplis ...
            } else
            {
                $_SESSION['echec'] = '<span class="h6 text-center"> Veillez remplire tous les champs</span>';
                header('Location: users.php'); 
            }
        }


       
    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::           
        

// PHASE DE MISE A JOUR DE PROFIL ELEVE

        if (isset($_POST['updatebtn'])) {
            $id = $_POST['edit_id'];
            $username = $_POST['edit_name'];
            $genre = $_POST['edit_genre'];
            $age = $_POST['edit_year'];
            $matricule = $_POST['edit_matricule'];
            $classe = $_POST['edit_classe'];
            $password = $_POST['edit_password'];
            $cpassword = $_POST['confirmpassword'];
             $photo = $_FILES["file"]["name"];

        //  add file
        $target_dir = "upload/";//dossier de reception
        $target_file = $target_dir . basename($photo);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                // Check if image file is a actual image or fake image
        
        //     $check = getimagesize($_FILES["file"]["tmp_name"]);
        //     if($check !== false) {
        //         header('Location:users.php');
        //         echo "File is an image - " . $check["mime"] . ".";
        //     $uploadOk = 1;
        // } else {
        //     header('Location:users.php');
        //     $_SESSION['echec'] = "<span class='h6 text-center'>File is not an image.</span>";
        //     $uploadOk = 0;
        // }
        
            // Check file size
            if ($_FILES["file"]["size"] > 3000000) {
                header('Location:users.php');
                $_SESSION['echec'] = "<span class='h6 text-center'>Désolé, choisissez une photo < 3Mo.</span>";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" && $imageFileType != "jfif" ) {
                header('Location:users.php');
                $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</span>";
                $uploadOk = 0;
            }
            
       
                # code...
                //renomer l'image s'il  existe
                $temp = explode(".", $photo);
                $newfilename = round(microtime(true)) . '.' . end($temp);
                $finaldestination = $target_dir. $newfilename;
                //}
            

          
    
        if ($username && $genre && $age && $matricule  && $classe &&  $password && $cpassword) {

            if ($password === $cpassword) {

                
                # code...
                $query = "UPDATE etudiants SET nom ='$username', genre ='$genre', dnaissance ='$age', classe ='$classe', image ='$finaldestination', matricule='$matricule ', motdepasse='$password' WHERE id='$id'";
                $query_run = mysqli_query($connection, $query);

                if($query_run)
                {

                    // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    header('Location:users.php');
                    $_SESSION['echec'] = "<span class='h6 text-center'>La photo de profil n'a pas été modifiée.</span>";
                
                        
                        // if everything is ok, try to upload file
                        } else {
                            if (move_uploaded_file($_FILES["file"]["tmp_name"], "".$finaldestination)) {
                            echo "The file ". htmlspecialchars( basename( $photo)). " has been uploaded.";
                            } else {

                            $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, there was an error uploading your file.</span>";
                             header('Location:usrs.php');
                        
                            }
                        }

                    // echo "Enregistré";
                    $_SESSION['success'] = "<span class='h6 text-center'>Profil modifié avec succès</span>";
                    header('Location: users.php');
                }
                else
                {
                    $_SESSION['echec'] = "<span class='h6 text-center'> Echec lors de la modification</span>";
                    header('Location: users.php'); 
                }
            

            }else 
                    {
                        $_SESSION['echec'] = "<span class='h6 text-center'>Vérifiez que vos deux mots de passes sont identiques'</span>";
                       
                        header('Location: users.php'); 
                    }
                    
                    // autrement si tous les champs ne sont pas remplis ...
            } else
            {
                $_SESSION['echec'] = '<span class="h6 text-center"> Veillez remplire tous les champs</span>';
                header('Location: users.php'); 
                }
            }


//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


                // OPERATION DE SUPPRESSION DES ELEVES

                if (isset($_POST['deletebtn'])) {
                    $id = $_POST['delete_id'];

                    $query = "DELETE  FROM etudiants WHERE id='$id' ";
                    $query_run = mysqli_query($connection, $query);

                    if ($query_run) {

                        $_SESSION['success'] = "L'élève ne fait plus partir de la base de donnée";
                        header('Location: users.php'); 

                    }else {
                        $_SESSION['echec'] = "L'élève n'a pas été supprimé";
                        header('Location: users.php'); 

                    }
                }

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

// ENREGISTREMENT DES ADMINISTRATEURS ET DES EDITEURS

if(isset($_POST['adminbtn']))
{
        
        $username = $_POST['name'];
        $genre = $_POST['genre'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $cpassword = $_POST['confirmpassword'];
        $photo = $_FILES["file"]["name"];

        //  add file
        $target_dir = "upload/";//dossier de reception
        $target_file = $target_dir . basename($photo);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                // Check if image file is a actual image or fake image
        
        //     $check = getimagesize($_FILES["file"]["tmp_name"]);
        //     if($check !== false) {
        //         header('Location:users.php');
        //         echo "File is an image - " . $check["mime"] . ".";
        //     $uploadOk = 1;
        // } else {
        //     header('Location:users.php');
        //     $_SESSION['echec'] = "<span class='h6 text-center'>File is not an image.</span>";
        //     $uploadOk = 0;
        // }
        
            // Check file size
            if ($_FILES["file"]["size"] > 3000000) {
                header('Location:admin.php');
                $_SESSION['echec'] = "<span class='h6 text-center'>Désolé, choisissez une photo < 3Mo.</span>";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" && $imageFileType != "jfif" ) {
                header('Location:admin.php');

                $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</span>";
                $uploadOk = 0;
            }
            
       
                # code...
                //renomer l'image s'il  existe
                $temp = explode(".", $photo);
                $newfilename = round(microtime(true)) . '.' . end($temp);
                $finaldestination = $target_dir. $newfilename;
                //}
            

          
    
        if ($username && $genre && $mobile && $email && $password && $cpassword) {

            if ($password === $cpassword) {

                  //Verification de l'existance d'un élève

                    $check = "SELECT * FROM admins WHERE email ='$email'";
                    $result = mysqli_query($connection, $check);
                    $nombre = mysqli_num_rows($result);

                    if ($nombre > 0) {
                        //insertion
                        $_SESSION['echec'] = "<span class='h6 text-center'>l'élève existe.</span>";
                  
                        header('Location:admin.php');

                }
                else {
                // # code...
                $query ="INSERT INTO admins (`nom`, `mobile`, `email`, `genre`, `password`, `image`, `date_rec`) 
                VALUES ('$username','$mobile','$email','$genre','$password','$finaldestination','$date_poste')";
                $query_run = mysqli_query($connection, $query);

                if($query_run)
                {

                    // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    header('Location:admin.php');

                    $_SESSION['echec'] = "<span class='h6 text-center'>Administrateur ajouté sans photo de profile.</span>";
                
                        
                        // if everything is ok, try to upload file
                        } else {
                            if (move_uploaded_file($_FILES["file"]["tmp_name"], "".$finaldestination)) {
                            echo "The file ". htmlspecialchars( basename( $photo)). " has been uploaded.";
                            } else {

                            $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, there was an error uploading your file.</span>";
                            header('Location:admin.php');

                        
                            }
                        }

                    // echo "Enregistré";
                    $_SESSION['success'] = "<span class='h6 text-center'>Profil ajouté avec succès</span>";
                    header('Location:admin.php');

                }
                else
                {
                    $_SESSION['echec'] = "<span class='h6 text-center'> Echec lors de l'ajout</span>";
                    header('Location:admin.php');
 
                }
            }

            }else 
                    {
                        $_SESSION['echec'] = "<span class='h6 text-center'>Vérifiez que vos deux mots de passes sont identiques'</span>";
                       
                        header('Location:admin.php');
 
                    }
                    
                    // autrement si tous les champs ne sont pas remplis ...
            } else
            {
                $_SESSION['echec'] = '<span class="h6 text-center"> Veillez remplire tous les champs</span>';
                header('Location:admin.php');
 
            }
        }





        // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

// MISE A JOUR DU PROFIL ADMINISTRATEUR



if (isset($_POST['updateAdminbtn'])) {
    $id = $_POST['edit_id'];
    $username = $_POST['edit_name'];
    $genre = $_POST['edit_genre'];
    $mobile = $_POST['edit_mobile'];
    $email = $_POST['edit_email'];
    $password = $_POST['edit_password'];
    $cpassword = $_POST['confirmpassword'];
     $photo = $_FILES["file"]["name"];

//  add file
$target_dir = "upload/";//dossier de reception
$target_file = $target_dir . basename($photo);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image

//     $check = getimagesize($_FILES["file"]["tmp_name"]);
//     if($check !== false) {
//         header('Location:users.php');
//         echo "File is an image - " . $check["mime"] . ".";
//     $uploadOk = 1;
// } else {
//     header('Location:users.php');
//     $_SESSION['echec'] = "<span class='h6 text-center'>File is not an image.</span>";
//     $uploadOk = 0;
// }

    // Check file size
    if ($_FILES["file"]["size"] > 3000000) {
        header('Location:admin.php');

        $_SESSION['echec'] = "<span class='h6 text-center'>Désolé, choisissez une photo < 3Mo.</span>";
        $uploadOk = 0;
    }
    
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" && $imageFileType != "jfif" ) {
            header('Location:admin.php');
           
        $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</span>";
        $uploadOk = 0;
    }
    

        # code...
        //renomer l'image s'il  existe
        $temp = explode(".", $photo);
        $newfilename = round(microtime(true)) . '.' . end($temp);
        $finaldestination = $target_dir. $newfilename;
        //}
    

  

if ($username && $genre && $mobile && $email  &&  $password && $cpassword) {

    if ($password === $cpassword) {

        
        # code...nom	mobile	email	genre	password	image
        $query = "UPDATE admins SET nom ='$username', mobile ='$mobile', email='$email', genre ='$genre', image ='$finaldestination', password ='$password' WHERE id='$id'";
        $query_run = mysqli_query($connection, $query);

        if($query_run)
        {

            // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            header('Location:admin.php');
            $_SESSION['echec'] = "<span class='h6 text-center'>La photo de profil n'a pas été modifiée.</span>";
        
                
                // if everything is ok, try to upload file
                } else {
                    if (move_uploaded_file($_FILES["file"]["tmp_name"], "".$finaldestination)) {
                    echo "The file ". htmlspecialchars( basename( $photo)). " has been uploaded.";
                    } else {

                    $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, there was an error uploading your file.</span>";
                    header('Location:admin.php');

                
                    }
                }

            // echo "Enregistré";
            $_SESSION['success'] = "<span class='h6 text-center'>Profil modifié avec succès</span>";
            header('Location:admin.php');

        }
        else
        {
            $_SESSION['echec'] = "<span class='h6 text-center'> Echec lors de la modification</span>";
            header('Location:admin.php');
 
        }
    

    }else 
            {
                $_SESSION['echec'] = "<span class='h6 text-center'>Vérifiez que vos deux mots de passes sont identiques'</span>";
               
                header('Location:admin.php');
 
            }
            
            // autrement si tous les champs ne sont pas remplis ...
    } else
    {
        $_SESSION['echec'] = '<span class="h6 text-center"> Veillez remplire tous les champs</span>';
        header('Location:admin.php');
 
        }
}


//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


        // OPERATION DE SUPPRESSION DES Administrateurs

        if (isset($_POST['deleteAdminbtn'])) {
            $id = $_POST['delete_id'];

            $query = "DELETE  FROM admins WHERE id='$id' ";
            $query_run = mysqli_query($connection, $query);

            if ($query_run) {

                $_SESSION['success'] = "Administrateur supprimé avec succès";
                header('Location: admin.php'); 

            }else {
                $_SESSION['echec'] = "L'élève n'a pas été supprimé";
                header('Location: admin.php'); 

            }
        }


   

//OPElRATION DE SUPPRESSION DES OEUVRES
if (isset($_POST['deletebook'])) {
    $id = $_POST['delete_id'];

    $query = "DELETE  FROM tablehistoire WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Livres supprimé avec succès";
        header('Location: books.php'); 

    }else {
        $_SESSION['echec'] = "L'élève n'a pas été supprimé";
        header('Location: books.php'); 

    }
}

// PHASE DE CONNEXION ADMINISTRATEURS


if (isset($_POST['loginbtn'])) {
    $email_login = $_POST['email'];
    $password_login = $_POST['password']; 
     $query = "SELECT * FROM admins WHERE email ='$email_login' AND password ='$password_login'";
    $query_run = mysqli_query($connection, $query);
    $nombre = mysqli_num_rows($query_run );
    if($nombre == 1) {
    
    //   //aller à la page 
      $row = mysqli_fetch_array($query_run);
      $id = $row['id'];
    //  //Création de la session
    $_SESSION["id"] = $id;
       
      header('Location: adminProfile.php');
      

    }
    
    else{
        $_SESSION['echec'] = 'Mot de passe ou email incorrect !';

        header('Location: login.php');
    }
    
}

///::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

        //PHASE D'ENREGISTREMENT DES LIVRES

        if (isset($_POST['enregistrer'])) {
            $idadmin = $_POST['ida'];
            $type = ($_POST['type_histoire']);
            $age = mysqli_real_escape_string($connection, $_POST['limite_age']);
            $titre = mysqli_real_escape_string($connection, $_POST['titre']);
            $description = mysqli_real_escape_string ($connection, $_POST['description']);
            $summernote = trim(mysqli_real_escape_string ($connection,$_POST['summernote']));
            
            //check data

            $check = "SELECT * FROM tablehistoire WHERE titre ='$titre'";
            $result = mysqli_query($connection, $check);
            $nombre = mysqli_num_rows($result);
            

            
            //  add file
            $target_dir = "upload/";//dossier de reception
            $target_file = $target_dir . basename($_FILES["file"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                // Check if image file is a actual image or fake image
        
            $check = getimagesize($_FILES["file"]["tmp_name"]);
            if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
        
            // Check file size
            if ($_FILES["file"]["size"] > 3000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" && $imageFileType != "jfif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            

        //renomer l'image
        $temp = explode(".", $_FILES["file"]["name"]);
        $newfilename = round(microtime(true)) . '.' . end($temp);
        $finaldestination = $target_dir. $newfilename;
        //}
        

    if ($nombre > 0) {
            //insertion
        
        echo "l'oeuvre existe";
        header('Location:books.php');
    }
    else {

        $sql = "INSERT INTO tablehistoire (`idadmin`, `type_histoire_id`, `limit_age_id`, `titre`, `description`, `image`, `text_histoire`, `date_pub`)
        VALUES ('$idadmin','$type','$age','$titre','$description','$finaldestination','$summernote','$date_poste')";

        if (mysqli_query($connection, $sql)) {
                // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    echo "Sorry, your file was not uploaded.";
                    header('Location:books.php');
                // if everything is ok, try to upload file
                } else {
                    if (move_uploaded_file($_FILES["file"]["tmp_name"], "".$finaldestination)) {
                    echo "The file ". htmlspecialchars( basename( $_FILES["file"]["name"])). " has been uploaded.";
                    } else {
                    echo "Sorry, there was an error uploading your file.";
                    header('Location:books.php');
                    }
                }
            echo "Nouvelle histoire ajoutée avec succès";
        header('Location:books.php');

        } else {
            # code...
            echo "Error: " . $sql . "<br>" . mysqli_error($connection);
        }
        
    }
}
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

// PHASE DE MISE A JOUR DES LIVRES

if (isset($_POST['updatebooks'])) {
    $id = $_POST['edit_id'];
    $type = ($_POST['edit_type_histoire']);
    $age = mysqli_real_escape_string($connection, $_POST['edit_limit_age']);
    $titre = mysqli_real_escape_string($connection, $_POST['edit_titre']);
    $description = mysqli_real_escape_string ($connection, $_POST['edit_description']);
    $summernote = trim(mysqli_real_escape_string ($connection,$_POST['edit_summernote']));
    $photo = $_FILES["file"]["name"];

    //  add file
    $target_dir = "upload/";//dossier de reception
    $target_file = $target_dir . basename($photo);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            // Check if image file is a actual image or fake image
    
    //     $check = getimagesize($_FILES["file"]["tmp_name"]);
    //     if($check !== false) {
    //         header('Location:admin/books.php');
    //         echo "File is an image - " . $check["mime"] . ".";
    //     $uploadOk = 1;
    // } else {
    //     header('Location:admin/books.php');
    //     $_SESSION['echec'] = "<span class='h6 text-center'>File is not an image.</span>";
    //     $uploadOk = 0;
    // }
    
        // Check file size
        if ($_FILES["file"]["size"] > 3000000) {
            header('Location:books.php');
            $_SESSION['echec'] = "<span class='h6 text-center'>Désolé, choisissez une photo < 3Mo.</span>";
            $uploadOk = 0;
        }
        
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" && $imageFileType != "jfif" ) {
            header('Location:books.php');
            $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</span>";
            $uploadOk = 0;
        }
        
   
            # code...
            //renomer l'image s'il  existe
            $temp = explode(".", $photo);
            $newfilename = round(microtime(true)) . '.' . end($temp);
            $finaldestination = $target_dir. $newfilename;
            //}
        
            

            $query = "UPDATE tablehistoire SET type_histoire_id ='$type', limit_age_id ='$age', titre ='$titre', description ='$description',image ='$finaldestination', text_histoire = '$summernote ' WHERE id='$id'";
           
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {

                // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                header('Location:books.php');
                $_SESSION['echec'] = "<span class='h6 text-center'>La photo de profil n'a pas été modifiée.</span>";
            
                    
                    // if everything is ok, try to upload file
                    } else {
                        if (move_uploaded_file($_FILES["file"]["tmp_name"], "".$finaldestination)) {
                        echo "The file ". htmlspecialchars( basename( $photo)). " has been uploaded.";
                        } else {

                        $_SESSION['echec'] = "<span class='h6 text-center'>Sorry, there was an error uploading your file.</span>";
                         header('Location:books.php');
                    
                        }
                    }

                // echo "Enregistré";
                $_SESSION['success'] = "<span class='h6 text-center'>Livre modifié avec succès</span>";
                header('Location:books.php');
            }
            else
            {
                $_SESSION['echec'] = "<span class='h6 text-center'> Echec lors de la modification</span>";
                header('Location: books.php'); 
            }
        

        
      
        }



mysqli_close($connection);

?>

