<?php
session_start();
include ("connexion/connexion.php");
include 'session.php';

?>


<!DOCTYPE html>
<html lang="fr">

<head>
<title>Administrateurs</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="../fontawesome/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <!-- preview input image CSS -->
<link rel="stylesheet" href="css/jasny-bootstrap.min.css">
</head>

<body class="">
  <div class="wrapper ">
    
  <?php include'include/sidebar.php' ?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php include'include/topbar.php' ?>
      <!-- End Navbar -->

      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Modifier le profil</h4>
                  <p class="card-category">Completer les informations</p>
                </div>
                <div class="card-body">
                <?php
                   //  transfert des données à la page de modification à travers "Id"

                   include("connexion/connexion.php");
                    if (isset($_POST['edit_btn'])) {
                        # code...
                        $id=$_POST['edit_id'];
                        
                        
                        $query = "SELECT * FROM etudiants WHERE id='$id' ";
                        $query_run = mysqli_query($connection, $query);
                        
                        foreach($query_run as $row)
                        {
                            ?> 

                    <form action="code.php" method="POST" enctype='multipart/form-data'>

                    <input type="hidden" name="edit_id" value="<?php  echo $row['id']; ?>" class="form-control">
                        <div class="text-center">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <div class="fileinput-new img-thumbnail img-raised rounded-circle " data-trigger="fileinput" style="width: 200px; height: 200px;">
                                    <img src="<?php  echo $row['image']; ?>" alt="Circle Image" class="img-raised rounded-circle" width="200" height="200" style="object-fit: cover;">
                                    </div>
                                    <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px;"></div>
                                    <div>
                                        <span class="btn  btn-file btn-outline-primary btn-simple center" >
                                            <span class="fileinput-new"> 
                                            <i class="fa fa-camera-retro"></i>
                                        
                                            </span>
                                            <span class="fileinput-exists"><i class="fa fa-camera-retro fa-5x"></i></span>
                                            <input type="file" name="file" id="fileToUpload">
                                        </span>
                                        <a href="#" class="btn btn-outline-danger fileinput-exists" data-dismiss="fileinput"><i class="material-icons">close</i></a>
                                    </div>
                            </div>
                        </div>

                    <div class="row">
                        
                      <div class="col-md-6">
                        <div class="form-group">
                            <label >Nom et prénom(s):</label>
                            <input  type="text" name="edit_name" class="form-control" value="<?php  echo $row['nom']; ?>" >
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                        <label >Classe:</label>
                         <input  type="text" name="edit_classe" class="form-control" value="<?php  echo $row['classe']; ?>" >
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                        <label for="inputGenre" class="form-label">Genre:</label>
                            <select id="inputState" class="form-control selectpicker" name="edit_genre">
                                    <option value="<?php  echo $row['genre']; ?>"><?php  echo $row['genre']; ?></option>
                                    <option value="Homme">Homme</option>
                                    <option value="Femme">Femme</option>
                                    <option value="Autre">Autre</option>
                            
                            </select>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                        <label for="exampleInputEmail1">Matricule:</label>
                         <input  type="text" name="edit_matricule" class="form-control" value="<?php  echo $row['matricule']; ?>" >
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                        <label class="form-label">Date de naissance</label>
                        <input type="date" name="edit_year" value="<?php  echo $row['dnaissance']; ?>"class="form-control">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                        <label class="form-label">Mot de passe</label>
                         <input type="text" name="edit_password" class="form-control" value="<?php  echo $row['motdepasse']; ?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                        <label class="form-label">Confirmer Mot de passe</label>
                        <input type="text" name="confirmpassword" class="form-control" placeholder="Confirmer mot de passe">
                        </div>
                      </div>
                     
                    </div>
                    
                    <a href="users.php"  class="btn btn-danger">Annuler</a>
                    <button type="submit" name="updatebtn" class="btn btn-primary">Enregistrer</button>
                    <div class="clearfix"></div>
                 
                </form>

               
            
                </div>
              </div>
            </div>

            <div class="col-md-4">

              <div class="card card-profile">
              <div class="img-raised rounded-circle text-center ">
                   <img src="<?php  echo $row['image']; ?>" alt="Circle Image" class="img-raised rounded-circle " width="150" height="150" style="object-fit: cover;margin-top:-50px;margin-left :10px;">
                </div>
                <div class="card-body">
                <div class="name">
                    <h3 class="title"><?php  echo $row['nom']; ?></h3>
                    <h6><?php  echo $row['classe']; ?></h6>
                   
                </div>
                <div>
                    <p><span class="title h6">Genre : </span><span><?php  echo $row['genre']; ?></span></p>
                    <p><span  class="title h6">Matricule : </span><span><?php  echo $row['matricule']; ?></span></p>
                    <p><span class="title h6">Naissance : </span><span><?php  echo $row['dnaissance']; ?></span></p>
                   
                    
                </div>
                </div>

                <div class="text-center m-2"><p>Vous utilisez Story Books depuis le <span>
                    <?php  echo $row['date_poste']; ?></span></p></div>
              </div>

            </div>

          </div>

          <?php
                }

            }


            ?>
        </div>
      </div>
     
      <?php include'include/footer.php'?>

    </div>
  </div>
  
  <?php include'include/setting.php'?>


   <!--   Core JS Files   -->
   <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap-material-design.min.js"></script>
  <script src="js/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <script src="js/moment.min.js"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="js/sweetalert2.js"></script>
  <!-- Forms Validations Plugin -->
  <script src="js/jquery.validate.min.js"></script>
  <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="js/jquery.bootstrap-wizard.js"></script>
  <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
  <script src="js/bootstrap-datetimepicker.min.js"></script>
  <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
  <script src="js/jquery.dataTables.min.js"></script>
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="js/bootstrap-tagsinput.js"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="js/jasny-bootstrap.min.js"></script>
  <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
  <script src="js/fullcalendar.min.js"></script>
  <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
  <script src="js/jquery-jvectormap.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="js/nouislider.min.js"></script>
  <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
  <!-- Library for adding dinamically elements -->
  <script src="js/arrive.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="js/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="js/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="js/demo.js"></script>
      <!-- preview image imput JavaScript -->
<script src="js/jasny-bootstrap.min.js"></script>

  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }

        }

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
</body>

</html>