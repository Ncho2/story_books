<?php

if(isset($_SESSION["id"])){
   $id_sav = $_SESSION["id"];
    //Information Etudiant
    $check = "SELECT * FROM admins WHERE id ='$id_sav'";
    $result = mysqli_query($connection, $check);// execution requet check
    $nombre = mysqli_num_rows($result);// nombre de resultat
    $row = mysqli_fetch_assoc($result);// sauv information des champs de la table dans row
    // $id = $row['id'];
    $nom = $row['nom'];
    $mobile = $row['mobile'];
    $date_post = $row['date_rec'];
    $image = $row['image'];
    $email = $row['email'];
    $genre = $row['genre'];

    // echo 'WELCOME!!! '.$nom.'<br>';

}else{
    header('Location: login.php');
    
}

?>