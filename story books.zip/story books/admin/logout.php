<?php
 session_start();

// code logout adminitrateur

if (isset($_POST['logoutbtn'])) {
        
    session_destroy();
 
    header('Location: login.php');

    $_SESSION['button'];
}

?>