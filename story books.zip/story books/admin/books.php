<?php
session_start();
include ("connexion/connexion.php");
include 'session.php';

?>



<!DOCTYPE html>
<html lang="fr">
<head>

<title>Administrateurs</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="../fontawesome/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
   
   

</head>

<body class="bg-light">
  <div class="wrapper ">
    <?php include'include/sidebar.php'; ?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php include'include/topbar.php';?>
      <!-- End Navbar -->
       
    <div class="content"> 
       

            <div class="card card-nav-tabs card-plain">
            <div class="card-header card-header-success">
                <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
                <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                        <ul class="nav nav-tabs" data-tabs="tabs">
                            <li class="nav-item">
                                <a class="nav-link active" href="#books" data-toggle="tab">
                                <i class="material-icons">library_books</i>
                                Tous les livres
                                </a>
                            </li>  
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-body ">
                <div class="tab-content text-center">
                    <div class="tab-pane active" id="books">
                    <div class="d-absolute">
            
            <?php
                    if (isset($_SESSION['echec'])) {
                                    ?>
                    <div class="alert alert-danger p-2">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span>
                     <?php
                                    # code...
                                    echo $_SESSION['echec'];
                                    unset($_SESSION['echec']);
                                } else {
                                    # code...
                                    echo "";
                                }
                                
                                ?>
                            
                                </span>
                       <?php ?>
                      </div>
                      <?php
                    ?>
    
                      <?php
                    if (isset($_SESSION['success'])) {
                                    ?>
                    <div class="alert alert-success p-2">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span>
                     <?php
                                    # code...
                                    echo $_SESSION['success'] ;
                                    unset($_SESSION['success']);
                                } else {
                                    # code...
                                    echo "";
                                }
                                
                            
                                ?>
                            
                                </span>
                       <?php ?>
                      </div>
                      <?php
                    ?>
                
            </div>
                        
                    <div class="row ">
        <?php
            include 'connexion/connexion.php';

                $query = "SELECT * FROM tablehistoire WHERE idadmin = '$nom'" ;
                $result = mysqli_query($connection, $query);
    
            while($row = mysqli_fetch_assoc($result))
                {
             ?>


                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header ">
                                <div class="img-raised rounded-circle ">
                                <img src="<?php echo $row['image']; ?>" class="img-fluid rounded-start mt-2" alt="..." style="max-height:70px;margin-left:50px">
                                </div>
                            </div>
                            <div class="card-body">
                               <div class="text-center">
                                    <h6 class="title mt-0" name="titre"><?php  echo $row['titre']; ?></h6>
                                        <div class="row mx-auto mt-0">
                                            <p><span class="h6">Genre : </span><span name=""> <?php  echo $row['type_histoire_id']; ?> </span> </p>
                                            
                                        </div>
                                        <div class="row mx-auto">
                                            <p> <span class="h6">Age:</span> <span name="age"><?php  echo $row['limit_age_id']; ?></span></p>
                                            
                                        </div>
                                        <div class="row mx-auto">
                                        <p><span class="h6">Publié le:</span>
                                            <span name="date_pub"><?php echo $row['date_pub'] ?>
                                            </span>
                                        </p>
                                        </div>
                               
                                    <div class="row mx-3">
                                    
                                        <form action="readbooks.php" method="POST" class="mt-0 ">
                                            <button type="submit"name="readb_btn" class="btn btn-primary "  style="height: 50px;padding: 15px;">
                                                <i class="material-icons">visibility</i>
                                                <input type="hidden" name="readb_id" value="<?php echo $row['id']; ?>" >
                                            </button>
                                          </form>
                                           
                                         

                                        <form action="edit_books.php" method="POST">
                                            <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>" >
                                            <button type="submit" name="editbookbtn" data-toggle="tooltip" data-placement="top"  class="btn btn-success btn-simple" style="height: 50px;padding: 15px;"> 
                                                <i class="material-icons">edit</i>
                                            </button>
                                        </form>
                                        <form action="code.php" method="POST">
                                            <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                            <button type="submit" name="deletebook" data-toggle="tooltip" data-placement="top"  class="btn btn-danger btn-simple" style="height: 50px;padding: 15px;">
                                                <i class="material-icons">close</i>
                                              </button>
                                          </form>
                                      </div>
                                </div>
                              </div>
                          </div>
                        </div> 

                        <?php } ?> 
    
                    </div>
                </div>
               </div>
            </div>
        </div>
        
    </div>

                
        
        
            


               


      <!-- footer -->

      <?php include'include/footer.php'?>
    </div>
  </div>

  
  
    <!--   Core JS Files   -->
    <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap-material-design.min.js"></script>
  <script src="js/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <script src="js/moment.min.js"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="js/sweetalert2.js"></script>
  <!-- Forms Validations Plugin -->
  <script src="js/jquery.validate.min.js"></script>
  <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="js/jquery.bootstrap-wizard.js"></script>
  <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="js/bootstrap-selectpicker.js"></script>
  
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="js/bootstrap-tagsinput.js"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="js/jasny-bootstrap.min.js"></script>
  
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="js/nouislider.min.js"></script>
  <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
  <!-- Library for adding dinamically elements -->
  <script src="js/arrive.min.js"></script>

  <!-- Chartist JS -->
  <script src="js/plugichartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="js/bootstrap-notify.js"></script>
  
  <script>


    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }

        }

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();

    });
  </script>
</body>

</html>

