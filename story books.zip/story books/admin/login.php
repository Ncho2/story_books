<?php
session_start();
include("connexion/connexion.php");

  
?>


<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="./assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Connexion
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="http://localhost/story%20books/fontawesome/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="css/material-kit.css?v=2.0.7" rel="stylesheet" />
 

</head>

<body class="index-page sidebar-collapse">
    


  
  <div class="page-header header-filter clear-filter purple-filter " data-parallax="true" style="background-image: url('images/biblio.jfif');height:250px">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto">
          <div class="brand">
            <h1>Bienvenue</h1>
            <h3> à la Bibliothèque Numérique des Belles Histoires.</h3>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="main main-raised " style="margin-top: -20px; height: 450px;">
  <div class="container">
      <div class="row">
        <div style="margin-left: 400px;">
          <div class="card card-login" style=" height:380px; width:350px">

            <form method="POST" action="code.php">
              <div class="card-header card-header-primary text-center">
                <h4 class="card-title">Connexion</h4>
               
              </div>

              <?php
                    if (isset($_SESSION['echec'])) {
                      ?>
                     <?php echo'

              <div class="alert alert-danger">
              
                  <div class="alert-icon">
                    <i class="material-icons">error_outline</i>
                  </div>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true"><i class="material-icons">clear</i></span>
                  </button>
                  <b>Erreur:</b> Mot de passe ou matricule incorrect !
                
            </div>' ?>
             
              <?php 
               }
               ?>
 
              <div class="card-body">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">email</i>
                    </span>
                  </div>
                  <input type="email" name="email" class="form-control" placeholder="Entrez votre e-mail">
                </div>
               
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">lock_outline</i>
                    </span>
                  </div>
                  <input type="password" name="password" class="form-control" placeholder="Mots de passe...">
                </div>
              </div>
              <div class="footer text-center">
                <button  class="btn btn-primary btn-link" type="submit" name="loginbtn">Commencer</button>
                <p> J'ai oublié mon <a href="passRecover.php">Mot de Passe</a></p>
              </div>
         
            </form>
            
          </div>
        </div>
      </div>
    </div>
    </div>

  <!--   Core JS Files   -->
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/popper.min.js" type="text/javascript"></script>
  <script src="js/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="js/moment.min.js"></script>
  <!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
  <script src="js/bootstrap-datetimepicker.js" type="text/javascript"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="js/nouislider.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="js/material-kit.js?v=2.0.7" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      materialKit.initFormExtendedDatetimepickers();

      // Sliders Init
      materialKit.initSliders();
    });


    function scrollToDownload() {
      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }
  </script>
</body>

</html>