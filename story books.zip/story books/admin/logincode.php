<?php
session_start();
// include'security.php';
require_once("connexion/connexion.php");

    // code login adminitrateur

if (isset($_POST['loginbtn'])) {
    $email_login = $_POST['email'];
    $password_login = $_POST['password'];

    $query = "SELECT * FROM admins WHERE email='$email_login' AND password='$password_login' ";
    $query_run = mysqli_query($connection, $query);
    if($query_run) {
    
        $_SESSION['name'] = $email_login;
        header('Location: http://localhost/stories%20book/');
    }
    
    else{
        $_SESSION['echec'] = "  Mot de passe ou email incorrect !";
        // header('Location: index.php');
    }
    
}

?>