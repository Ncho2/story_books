<?php
session_start();
include ("connexion/connexion.php");
include 'session.php';

?>


        <meta charset="utf-8" />
        <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
        <link rel="icon" type="image/png" href="./assets/img/favicon.png">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>
            Ajouter une Histoire
        </title>
        <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
        <!-- CSS Files -->
        <link href="css/material-kit.css?v=2.0.7" rel="stylesheet" />
        <!-- preview input image CSS -->
        <link rel="stylesheet" href="css/jasny-bootstrap.min.css">
        <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
        <!-- summernote independences -->

            <script src="js/jquery.min.js" type="text/javascript"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
            <script src="js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
             <link href="summernote/summernote-bs4.css" rel="stylesheet">
            <script src="summernote/summernote.min.js"></script>

  </head>
  <body class="index-page sidebar-collapse">
  <div class="wrapper ">
    <?php include'include/sidebar.php'; ?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php include'include/topbar.php';?>

      <!-- End Navbar -->
   

    <div class="main main-raised" style="margin-top: 80px;">
        <div class="section section-basic">
        <h4 class="text-center mb-5">MODIFIER L'HISTOIRE</h4>
             <div class="container mx-5">
                
             <?php
                   //  transfert des données à la page de modification à travers "Id"

                   include("connexion/connexion.php");
                    if (isset($_POST['editbookbtn'])) {
                        # code...
                        $id=$_POST['edit_id'];
                        
                        
                        $query = "SELECT * FROM tablehistoire WHERE id='$id' ";
                        $query_run = mysqli_query($connection, $query);
                        
                        foreach($query_run as $row)
                        {
                            ?> 
                       
                 <form action="code.php" method="POST" enctype='multipart/form-data'>
                        <input type="hidden" name="edit_id" value="<?php  echo $row['id']; ?>" class="form-control">
                        <div style="margin-left:-70px">
                            
                        <div class="text-center">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <div class="fileinput-new img-thumbnail img-raised  " data-trigger="fileinput" style="width: 200px; height: 200px;">
                                    <img src="<?php  echo $row['image']; ?>" alt="Circle Image" class="img-raised " style="object-fit: cover;">
                                    </div>
                                    <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px;"></div>
                                    <div>
                                        <span class="btn  btn-file btn-outline-primary btn-simple center mt-3 pt-4" >
                                            <span class="fileinput-new"> 
                                            <i class="fa fa-camera-retro"></i>
                                        
                                            </span>
                                            <span class="fileinput-exists"><i class="fa fa-camera-retro fa-5x"></i></span>
                                            <input type="file" name="file" id="fileToUpload">
                                        </span>
                                        <a href="#" class="btn btn-outline-danger fileinput-exists mt-3" data-dismiss="fileinput"><i class="material-icons py-3">close</i></a>
                                    </div>
                            </div>
                        </div>
                        </div>

                        
                    <div class="row">
                        
                        <div class="col-md-3">
                                    <label for="inputCategories" class="form-label h6">Type d'histoire:</label>
                                    <select id="inputState" class="form-control selectpicker" name="edit_type_histoire">
                                    <option selected><?php echo $row['type_histoire_id'] ?></option>
                                    <option value="Adventure">Adventure</option>
                                    <option value="Motivation">Motivation</option>
                                    <option value="Roman">Roman</option>
                                    <option value="Poésie">Poésie</option>
                                    <option value="Drame">Drame</option>
                                    <option value="philosophie">philosophie</option>
                                    <option value="BD">BD</option>
                                    </select>
                                  
                                    
                                </div>
                                <div class="col-md-4">
                                    <label for="inputState" class="form-label h6">Limite âge:</label>
                                    
                                    <select id="inputState" class="form-control selectpicker" name="edit_limit_age">
                                    <option selected><?php echo $row['limit_age_id'] ?></option>
                                    <option value="+5">+5</option>
                                    <option value="+7">+7</option>
                                    <option value="+10">+10</option>
                                    <option value="+12">+12</option>
                                    <option value="+14">+14</option>
                                    <option value="+16">+16</option>
                                    </select>
                                </div>
                           
                        </div>
                       
                        
                        <div class="row">
                                <div class="col-md-10 mt-3">
                                            <label for="inputdescription" class="form-label h6">Titre:</label>
                                            <textarea class="form-control" name="edit_titre"  placeholder="Saisissez un titre"><?php echo $row['titre'] ?></textarea>
                                        </div>
                                        <div class="col-md-10">
                                            <label for="inputdescription" class="form-label h6">Description:</label>
                                            <textarea class="form-control" name="edit_description" id="" cols="100" rows="5" placeholder="Description"><?php echo $row['description'] ?></textarea>
                                        </div>                     
                                </div>
                                <textarea name="edit_summernote" id="summernote" cols="30" rows="10"><?php echo $row['text_histoire'] ?></textarea>
                                
                                <a href="books.php"  class="btn btn-danger">Annuler</a>
                                <button type="submit" name="updatebooks" class="btn btn-primary">Mettre à jour</button>
                               
                            
                </form>
                
                <?php
                }

            }


            ?>
            </div>
        </div>
    </div>
  

   

  <!-- footer -->
  <?php include'include/footer.php'?>
  </div>
  </div>
  <!--   Core JS Files   -->
    <!-- preview image imput JavaScript -->
<script src="js/jasny-bootstrap.min.js"></script>
  
  <script src="js/bootstrap-material-design.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="js/material-kit.js?v=2.0.7" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      materialKit.initFormExtendedDatetimepickers();

      // Sliders Init
      materialKit.initSliders();
    });


    function scrollToDownload() {
      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }
  </script>
   
   
   <script>
           $('#summernote').summernote({
                        placeholder: 'Saisissez votre histoire ici ',
                        tabsize: 2,
                        height: 300,
                        width:800,
                        toolbar: [
                            //   ['style', ['style']],
                            ['font', ['bold','italic', 'underline', 'clear']],
                            ['color', ['color']],
                            ['para', ['ul', 'ol', 'paragraph']],
                            ['insert', [ 'picture']],

                            //   ['table', ['table']],
                            //   ['insert', ['link', 'picture', 'video']],
                            //   ['view', ['fullscreen', 'codeview', 'help']]
                        ]
                    });
                    
    </script>
            

    <script src="js/bootstrap.bundle.js"></script>
   

      
  </body>
</html>
