<?php
// EXECUTION MODAL
if (isset($_POST['book_id'])) {
    # code...
    $output = '';
    $connection = mysqli_connect("localhost","root","","stories_bd");

    $query = "SELECT * FROM tablehistoire WHERE id = '".$_POST['book_id']."'";
    $result = mysqli_query($connection,$query);

    $output .= '
    
    <div style="margin-top: 10px;">';

    while ($row = mysqli_fetch_array($result))
    {
        $output .= '
        <div class="card mb-3" style="max-width: 200px;">
        <div class="row g-0">
            <div class="col-md-4">
            <img src='.$row['image'].' class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8">
            <div class="card-body">
            <h5 class="card-title" >'.$row['titre'].'</h5>
            <p class="card-text">Auteur : <span>Jean Claude</span></p>
            <p class="card-text">Publié le : <small class="text-muted">'.$row['date_pub'].'</small></p>
        </div>
        </div>
    </div>
    </div>

      <div class="scroll-div mb-5">
            <div class="scroll-object p-3 text-justify">
            '.$row['text_histoire'].'
            </div>
    </div>';
    }
    $output .= "</div>";
    
    echo $output;
    
}



?>