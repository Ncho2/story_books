setTimeout(function() {
  $("#close").fadeOut().empty();
}, 5000);


setTimeout(function(){
  document.getElementById('#close').className = 'waa';
}, 5000);