

<nav class="navbar navbar-expand-lg  bg-primary fixed-top " style="margin-left: 260px;">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
          <form class="form-inline ml-auto">
                        <div class="form-group has-default">
                            <input type="text" class="mr-2" placeholder="Recherche..." style=" padding: 15px;width: 300px;height:40px; border: 2px solid purple;border-radius: 10px;">
                        </div>
                        <button type="submit" class="btn btn-light btn-raised btn-fab btn-round mr-2">
                    <i class="material-icons">search</i>
                  </button>
                </form>
            <ul class="navbar-nav">
              <li class="nav-item dropdown">
                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img src="<?php echo $image ?>" alt="Circle Image" class="rounded-circle "width="40" height="40"  style=" object-fit: cover;">
                 
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                  <a class="dropdown-item" href="adminProfile.php">Profil</a>
                  <a class="dropdown-item" href="addHistory.php">Ecrire une histoire</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item"> <span  data-toggle="modal" data-target="#logoutModal">
                            Deconnexion
                  </span></a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>





       <!--logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Vous allez être deconnecté!</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Choisissez 'Oui' pour vous déconnecter ou 'Non' pour garder votre session.
                </div>
                <div class="modal-footer">
                <form action="logout.php" method="POST"> 
                    <button type="button" class="btn btn-success" data-dismiss="modal">Non</button>
                    <button type="submit" name="logoutbtn" class="btn btn-primary">Oui</button>
                </form>
                </div>
                </div>
            </div>
            </div>