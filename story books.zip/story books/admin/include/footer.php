
  <footer class="footer" data-background-color="red">
    <div class="container">
      <nav class="float-left">
        <ul>
          <li>
            <a href="">
              DigiTech
            </a>
          </li>
          <li>
            <a href="https://www.creative-tim.com/presentation">
              Apropos de notre équipe
            </a>
          </li>
          <li>
            <a href="">
              Blog
            </a>
          </li>
          <li>
            <a href="https://www.creative-tim.com/license">
              Licenses
            </a>
          </li>
        </ul>
      </nav>
      <div class="copyright float-right">
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script>, Faire avec <i class="material-icons" style="color:rgb(200,100,100)">favorite</i> Par
        <a href="https://www.creative-tim.com/" target="_blank">DigiTech</a> pour un meilleur site web.
      </div>
    </div>
  </footer>