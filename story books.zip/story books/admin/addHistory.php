<?php
session_start();
include ("connexion/connexion.php");
include 'session.php';

?>



        <meta charset="utf-8" />
        <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
        <link rel="icon" type="image/png" href="./assets/img/favicon.png">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>
            Ajouter une Histoire
        </title>
        <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
        <!-- CSS Files -->
        <link href="css/material-kit.css?v=2.0.7" rel="stylesheet" />
        <!-- preview input image CSS -->
        <link rel="stylesheet" href="css/jasny-bootstrap.min.css">
        <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
        <!-- summernote independences -->

            <script src="js/jquery.min.js" type="text/javascript"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
            <script src="js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
             <link href="summernote/summernote-bs4.css" rel="stylesheet">
            <script src="summernote/summernote.min.js"></script>

  </head>
  <body class="index-page sidebar-collapse">
  <div class="wrapper ">
    <?php include'include/sidebar.php'; ?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php include'include/topbar.php';?>

      <!-- End Navbar -->
   

    <div class="main main-raised" style="margin-top: 80px;">
        <div class="section section-basic">
        <h4 class="text-center mb-5">AJOUTER UNE HISTOIRE</h4>
        <div class="container mx-5">
                       
                       <form action="code.php" method="POST" class="row g-3" enctype="multipart/form-data">
                               <div class="col-md-3">
                                       <label for="inputCategories" class="form-label h6">Type d'histoire:</label>
                                       <select id="inputState" class="form-control selectpicker" name="type_histoire">
       
                                       <?php
                                       include("connexion/connexion.php");
                                       $sql = "SELECT id, type_histoire FROM categories";
                                       $result = mysqli_query($connection, $sql);
                                       
                                       if (mysqli_num_rows($result) > 0) {
                                               // output data of each row
                                               while($row = mysqli_fetch_assoc($result)) {
                                               
                                           ?>      
                                                   <option value="<?php echo $row['type_histoire'] ?>"><?php echo $row['type_histoire'] ?></option>
                                           <?php
                                               }
                                           } else {
                                               echo "0 results";
                                           }
                                           ?>
                                       </select>
                                       
                                   </div>
                                   <div class="col-md-2">
                                       <label for="inputState" class="form-label h6">Limite âge:</label>
                                       
                                       <select id="inputState" class="form-control selectpicker" name="limite_age">
                                       <?php
                                       include("connexion/connexion.php");
                                       $sql = "SELECT id, limite_age FROM ages";
                                       $result = mysqli_query($connection, $sql);
                                       
                                       if (mysqli_num_rows($result) > 0) {
                                               // output data of each row
                                               while($row = mysqli_fetch_assoc($result)) {
                                           ?>  
                                   
                                           <option value="<?php echo $row['limite_age'];?>"> <?php echo $row['limite_age'];?></option>
                                           
                                           <?php
                                               }
                                           } else {
                                               echo "0 results";
                                           }
                                           ?>
                                       </select>
                                   </div>
                                   <div class="col-md-10 mt-3">
                                       <label for="inputdescription" class="form-label h6">Titre:</label>
                                       <textarea class="form-control" name="titre"  placeholder="Saisissez un titre"></textarea>
                                   </div>
                                   <div class="col-md-10">
                                       <label for="inputdescription" class="form-label h6">Description:</label>
                                       <textarea class="form-control" name="description" id="" cols="100" rows="5" placeholder="Description"></textarea>
                                   </div>
                                   <div class="col-md-4">
                                   <div class="text-center">
                                   <div class="fileinput fileinput-new" data-provides="fileinput">
                                           <div class="fileinput-new img-thumbnail img-raised  " data-trigger="fileinput" style="width: 200px; height: 200px;">
                                           <img src="images/camera.png" alt="Circle Image" class="img-raised " style="object-fit: cover;">
                                           </div>
                                           <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px;"></div>
                                           <div>
                                               <span class="btn  btn-file btn-outline-primary btn-simple center mt-3 pt-4" >
                                                   <span class="fileinput-new"> 
                                                   <i class="fa fa-camera-retro"></i>
                                               
                                                   </span>
                                                   <span class="fileinput-exists"><i class="fa fa-camera-retro fa-5x"></i></span>
                                                   <input type="file" name="file" id="fileToUpload">
                                               </span>
                                               <a href="#" class="btn btn-outline-danger fileinput-exists mt-3" data-dismiss="fileinput"><i class="material-icons py-3">close</i></a>
                                           </div>
                                   </div>
                               </div>
                                   </div>
       
                                   <textarea name="summernote" id="summernote" cols="30" rows="10"></textarea>
                                   <input type="hidden" name="ida" value="<?php  echo $nom ?>">
       
                                   <div class="col-12 mb-5">
                                       <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
                                       <a href="books.php" class="btn btn-danger">Annuler</a>
                                   </div>
       
                       </form>
                       
               
                   </div>
        </div>
    </div>
  

   

  <!-- footer -->
  <?php include'include/footer.php'?>
  </div>
  </div>
  <!--   Core JS Files   -->
    <!-- preview image imput JavaScript -->
<script src="js/jasny-bootstrap.min.js"></script>
  
  <script src="js/bootstrap-material-design.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="js/material-kit.js?v=2.0.7" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      materialKit.initFormExtendedDatetimepickers();

      // Sliders Init
      materialKit.initSliders();
    });


    function scrollToDownload() {
      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }
  </script>
   
   
   <script>
           $('#summernote').summernote({
                        placeholder: 'Saisissez votre histoire ici ',
                        tabsize: 2,
                        height: 300,
                        width:800,
                        toolbar: [
                            //   ['style', ['style']],
                            ['font', ['bold','italic', 'underline', 'clear']],
                            ['color', ['color']],
                            ['para', ['ul', 'ol', 'paragraph']],
                            ['insert', [ 'picture']],

                            //   ['table', ['table']],
                            //   ['insert', ['link', 'picture', 'video']],
                            //   ['view', ['fullscreen', 'codeview', 'help']]
                        ]
                    });
                    
    </script>
            

    <script src="js/bootstrap.bundle.js"></script>
   

      
  </body>
</html>
