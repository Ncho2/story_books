
<?php

$date_poste = date('Y-m-d');
$connection = mysqli_connect("localhost","root","","stories_bd");


if (!$connection) {
    # code...
    die("connexion échouée : ".mysqli_connect_errno());
}
else {
    # code...
    // echo "connexion réussie <br>";
}

?>