<?php
session_start();
include ("connexion/connexion.php");
include 'session.php';

?>


<!doctype html>
<html lang="fr">

<head>

  <title>Dashboard</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />


</head>

<body class="bg-light">
  <div class="wrapper ">
    <?php include'include/sidebar.php'; ?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php include'include/topbar.php';?>
      <!-- End Navbar -->
       
      <div class="content">
        <div class="container-fluid">
          <div class="row">

            <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card card-stats">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">people</i>
                  </div>
                  <p class="card-category">Administrateurs</p>
                  <h3 class="card-title">
                    <small><?php
            include 'connexion/connexion.php';
            $query = "SELECT id FROM admins ORDER BY id";
            $result = mysqli_query($connection, $query);
            $row = mysqli_num_rows($result);
             
            echo '<span>'.$row. '</span>'; 

              ?></small>
                  </h3>
                </div>
                <div class="card-footer bg-warning">
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card card-stats">
                <div class="card-header card-header-success card-header-icon">
                  <div class="card-icon">
                  <i class="fa fa-book" aria-hidden="true"></i>
                  </div>
                  <p class="card-category">Livres</p>
                  <h3 class="card-title">
                    +
                    <small><?php
            include 'connexion/connexion.php';
            $query = "SELECT id FROM tablehistoire ORDER BY id";
            $result = mysqli_query($connection, $query);
            $row = mysqli_num_rows($result);
             $num =$row -1;
            echo '<span>'.$num. '</span>'; 

              ?></small>
                  </h3>
                </div>
                <div class="card-footer bg-success">
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card card-stats">
                <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                  <i class="fa fa-users" aria-hidden="true"></i>
                  </div>
                  <p class="card-category">Utilisateurs</p>
                  <h3 class="card-title">
                    +
                    <small><?php
            include 'connexion/connexion.php';
            $query = "SELECT id FROM etudiants ORDER BY id";
            $result = mysqli_query($connection, $query);
            $row = mysqli_num_rows($result);
             $num =$row -1;
            echo '<span>'.$num. '</span>'; 

              ?></small>
                  </h3>
                </div>
                <div class="card-footer bg-danger">
                </div>
              </div>
            </div>

          </div>

        <!-- tables -->
          <div class="row">
         
            <div class="col-lg-6 col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">LIVRES RECENTS</h4>
                  <p class="card-category">Les livres de la semaine</p>
                </div>
                <div class="card-body table-responsive">
                <?php
                include 'connexion/connexion.php';
                $query = "SELECT * FROM tablehistoire "; 
                // WHERE id = '$id_sav'
                $result = mysqli_query($connection, $query);
                ?>
                  <table class="table table-hover">
                    <thead class="text-danger">
                      <th>ID</th>
                      <th>Titre</th>
                      <th>Âge limite</th>
                      <th>Publié le:</th>
                    </thead>
                    <tbody>
                    <?php
                       
                        
                       while($row = mysqli_fetch_assoc($result))
                       {

                       ?>
                      <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['titre']; ?></td>
                        <td><?php echo $row['limit_age_id']; ?></td>
                        <td><?php echo $row['date_pub']; ?></td>
                      </tr>
                      <?php }  
                        
                        ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-12">
              <div class="card">
                <div class="card-header card-header-info">
                  <h4 class="card-title">NOS ADMINS.</h4>
                  <p class="card-category">Les plus récemments</p>
                </div>
                <div class="card-body table-responsive">
                <?php
                include 'connexion/connexion.php';
                $query = "SELECT * FROM admins "; 
                // WHERE id = '$id_sav'
                $result = mysqli_query($connection, $query);
                ?>
                  <table class="table table-hover">
                    <thead class="text-success">
                      <th>ID</th>
                      <th>Name</th>
                      <th>Mobile</th>
                      <th>Genre</th>
                    </thead>
                    <tbody>
                    <?php
                       
                        
                       while($row = mysqli_fetch_assoc($result))
                       {

                       ?>
                      <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['nom']; ?></td>
                        <td><?php echo $row['mobile']; ?></td>
                        <td><?php echo $row['genre']; ?></td>
                      </tr>
                      <?php }  
                        
                        ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      <!-- footer -->

      <?php include'include/footer.php'?>
    </div>
  </div>



  <!--   Core JS Files   -->
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap-material-design.min.js"></script>
  <script src="js/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <script src="js/moment.min.js"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="js/sweetalert2.js"></script>
  <!-- Forms Validations Plugin -->
  <script src="js/jquery.validate.min.js"></script>
  <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="js/jquery.bootstrap-wizard.js"></script>
  <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="js/bootstrap-selectpicker.js"></script>
  
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="js/bootstrap-tagsinput.js"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="js/jasny-bootstrap.min.js"></script>
  
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="js/nouislider.min.js"></script>
  <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
  <!-- Library for adding dinamically elements -->
  <script src="js/arrive.min.js"></script>

  <!-- Chartist JS -->
  <script src="js/plugichartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="js/bootstrap-notify.js"></script>

  
  <script>


    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }

        }

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();

    });
  </script>
</body>

</html>