
<?php
include("connexion/connexion.php");


  
?>

<nav class="navbar navbar-transparent  navbar-color-on-scroll fixed-top navbar-expand-lg" color-on-scroll="50" id="sectionsNav">
    <div class="container-fluid">
      <div class="navbar-translate">
        <a href="http://localhost/story%20books/admin/dashboard.php">
        <i class="material-icons mr-4">dashboard</i>
        </a>
        <a class="navbar-brand" href="index.php">
         Story Books </a>
        <a href=""> plus de 200 Histoires</a>
      </div>
      <div class="collapse navbar-collapse">

        <ul class="navbar-nav ml-auto">

          <li class="nav-item">
                <form class="form-inline ml-auto" action="search.php" method="GET">
                        <div class="form-group has-default">
                            <input type="text" class="mr-2 px-3" name="search" placeholder="Search" style="width: 300px;height:40px; border: 2px solid purple;border-radius: 10px;">
                        </div>
                        <button type="submit" name="searchbtn" class="btn btn-primary btn-raised btn-fab btn-round mr-2">
                    <i class="material-icons">search</i>
                  </button>
                </form>
          </li>
          <li class="nav-item">
            <?php 
          if(! $_SESSION["matricule"]) {
              echo' <a href="login.php"><button class="btn btn-outline-primary btn-round mr-2">Connexion</button></a>';
            }else {
              echo '<p class=" h6 mx-2">Bienvenue!<span style ="font-style: italic;"> '.$username.'</span></p>';
            }
            ?>
            
         
          </li>
          <li class="dropdown nav-item">
                <a href="javascript:;" class="profile-photo dropdown-toggle nav-link" data-toggle="dropdown">
                    <div class="profile-photo-small">
                    <img src="admin/<?php echo $row['image'];?>" alt="Circle Image" class="rounded-circle "width="40" height="40"  style=" object-fit: cover;">
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <h6 class="dropdown-header">Menu</h6>
                    <!-- <a href="addHistory.php" class="dropdown-item">Ecrire une Histoire</a> -->
                    <a href="usersProfile.php" class="dropdown-item">Mon Profil</a>
                    <a class="dropdown-item">
              
                    <span  data-toggle="modal" data-target="#logoutModal">
                            Deconnexion
                  </span></a>
                </div>
            </li>

          
        </ul>

      </div>
    </div>
  </nav>



    <!--logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Vous allez être deconnecté!</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Choisissez 'Oui' pour vous déconnecter ou 'Non' pour garder votre session.
                </div>
                <div class="modal-footer">
                <form action="logout.php" method="POST"> 
                    <button type="button" class="btn btn-success" data-dismiss="modal">Non</button>
                    <button type="submit" name="logoutbtn" class="btn btn-primary">Oui</button>
                </form>
                </div>
                </div>
            </div>
            </div>