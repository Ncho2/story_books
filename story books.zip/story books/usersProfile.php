<?php
 session_start();
//Vérrification de connection
include 'connexion/connexion.php';
include 'session.php';



?>

        <meta charset="utf-8" />
        <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
        <link rel="icon" type="image/png" href="./assets/img/favicon.png">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>
            Ajouter une Histoire
        </title>
        <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
        <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
        <!-- CSS Files -->
        <link href="css/material-kit.css?v=2.0.7" rel="stylesheet" />


            <script src="js/core/jquery.min.js" type="text/javascript"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
   
    <link rel="stylesheet" href="css/style.css">

  </head>
  <body class="index-page sidebar-collapse">
    <?php include'include/topbar.php'?>

    <div class="page-header header-filter clear-filter purple-filter" data-parallax="true" style="background-image: url('images/bg_profile.jpg'); height:350px">
        <div class="container">
       
            <div class="col-md-8 ml-auto mr-auto">
                <div class="brand">
                    <h3 class="title">Mon Profil</h3>
                 </div>
            </div>
       
        </div>
    </div>

    <div class="main main-raised ">
        <div class="profile-content pb-5" >
            <div class="container  ">

                <div class="row">
                    <div class=" mx-auto">
                        <div class="profile text-center" style="margin-top: -60px;">
                            <div class="avatar d-flex">
                                <img src="admin/<?php echo $row['image'];?>" alt="Circle Image" class="img-raised rounded-circle" width="200" height="200" style="object-fit: cover;">
                               <a href=""><img src="images/camera.png" alt="" class="camera"></a> 
                             
                            </div>
                            <div class="name">
                                <h3 class="title"><?php echo $username?></h3>
                                <h6><?php echo $classe ?></h6>
                                <a href="#pablo" class="btn btn-just-icon btn-link btn-linkedin"><i class="fa fa-linkedin"></i></a>
                                <a href="#pablo" class="btn btn-just-icon btn-link btn-twitter"><i class="fa fa-twitter"></i></a>
                                <a href="#pablo" class="btn btn-just-icon btn-link btn-pinterest"><i class="fa fa-whatsapp"></i></a>
                            </div>
                            <div>
                                <p><span class="title">Genre : </span><span><?php echo $usergenre?></span></p>
                                <p><span  class="title">Matricule : </span><span><?php echo $matricule ?></span></p>
                                
                            </div>
                          

                        </div>
                    </div>
                   

                </div>

                <div class="text-center " ><p>Vous utilisez Story Books depuis le <span><?php echo $date_post ?></span></p></div>

            
            </div>
        </div>
    </div>
   
<!-- footer -->
      
<?php include'include/footer.php'?>
   <!--   Core JS Files   -->
   <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/popper.min.js" type="text/javascript"></script>
  <script src="js/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="js/moment.min.js"></script>
  <!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
  <script src="js/bootstrap-datetimepicker.js" type="text/javascript"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="js/nouislider.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="js/material-kit.js?v=2.0.7" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      materialKit.initFormExtendedDatetimepickers();

      // Sliders Init
      materialKit.initSliders();
    });


    function scrollToDownload() {
      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }
  </script>
               

    <script src="js/bootstrap.bundle.js"></script>
   

      
  </body>
</html>
