<?php
session_start();
    //Inclusion de la connexion à la BD
    require_once("connexion/connexion.php");
    include 'session.php';



// PHASE DE CONNEXION ELEVES


if (isset($_POST['loginbtn'])) {
    $matricule_login = $_POST['matricule'];
    $password_login = $_POST['password'];

    $query = "SELECT * FROM etudiants WHERE matricule ='$matricule_login' AND motdepasse='$password_login'";
    $query_run = mysqli_query($connection, $query);
    $nombre = mysqli_num_rows($query_run );
    if($nombre == 1) {
    
    //   //aller à la page 
    //   $row = mysqli_fetch_array($query_run);
    //   $id = $row['id'];
    //  //Création de la session
    // $_SESSION["id"] = $id;
        $_SESSION["matricule"] = $matricule_login ;
      header('Location: index.php');
      

    }
    
    else{
        $_SESSION['echec'] = 'Mot de passe ou matricule incorrect !';

        header('Location: login.php');
    }
    
}









mysqli_close($connection);


?>