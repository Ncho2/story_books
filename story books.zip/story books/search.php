<?php
session_start();
include("connexion/connexion.php");
include 'session.php';
?>


<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="./assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Material Kit by Creative Tim
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="css/material-kit.css?v=2.0.7" rel="stylesheet" />

</head>

<body class="index-page sidebar-collapse">
    
 <?php
    include'include/topbar.php'
 ?>


  <div class="page-header header-filter clear-filter purple-filter" data-parallax="true" style="background-image: url('./assets/img/bg2.jpg');height:350px">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto">
          <div class="brand">
            <h1>Resultats de la recherche.</h1>
            <h3>La Bibliothèque Numérique des Belles Histoires.</h3>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="main main-raised">
    <div class="section section-basic">
      <div class="container-fluid">

        <div class="title">
        <h2>Resultat(s) trouvé(s)
        </div>

            <?php
            
            $button = $_GET['searchbtn'];
            $search = $_GET['search'];

            include("connexion/connexion.php");

            $sql = "SELECT * FROM tablehistoire WHERE MATCH(id,idadmin,titre,description,text_histoire) AGAINST ('%" . $search ."%')";
            
            $run =mysqli_query($connection, $sql);
            
            $number = mysqli_num_rows($run);

            if($number==0){
               echo " <h4>Resultat(s) trouvé(s) : Aucun résultat trouvé";
            
            }else{
              echo "<h4>Resultat(s): $number résultat(s) trouvé(s) pour \"" .$search. "\"</h4> ";


            }

            // Obtenir le nombre de résultats  de la base de donnée

            $sql = "SELECT * FROM tablehistoire WHERE MATCH(id,idadmin,titre,description,text_histoire) AGAINST ('%" . $search ."%')";
            
            $runget =mysqli_query($connection, $sql);
            
            $numberget = mysqli_fetch_array($runget);
            while($numberget)
            {   $getid = $numberget['id'];
                $getidadmin = $numberget['idadmin'];
                $gettitre =$numberget['titre'];
                $gettype =$numberget['type_histoire_id	'];
                $getlimitage =$numberget['limit_age_id'];
                $getdescription =$numberget['description'];
                $getimage =$numberget['image'];
                $gettext =$numberget['text_histoire'];


               echo" <div class='card mb-3 mx-2' style='max-width: 350px;max-height:290px;'>
                <div class='row'>
                    <div class='col-md-7'>


                        <div class='card-body text-left'>
                          <h6 class='title mt-0' name='titre'>".$numberget['titre']."</h6>
                            <div class='row'>
                            <p><span class='h6'>Genre : </span><span> $gettype </span> </p>
                                
                            </div>
                            <div class='row'>
                                <p> <span class='h6'>Age:</span> <span name='age'> $getlimitage </span></p>
                                
                            </div>
                            <div class='row'>
                            <p><span class='h6'>Description:</span>
                                <span class='h-25' name='description'><?php echo (html_entity_decode(
                                    substr('$getdescription;' ,0, 20)). 
                                    '...') ?>
                                </span>
                            </p>
                            </div>
                                <form action='read.php' method='POST' class='mt-0'>
                                    <input type='hidden' name='read_id' value=' $getid' >
                                    <button type='submit' name='read_btn' class='btn btn-raised btn-primary col-12'>Lire l'histoire</button>
                                </form>
                           
                        </div>
                    
                    </div>
                    <div class='col-md-5'>
                        <img src='admin/$getimage' class='img-fluid rounded-start mt-2' alt='...' style='max-height:250px'>
                    </div>
                </div>
            </div>";
            }

mysqli_close($connection);
            ?>

    </div>
    </div>
  </div>



           
        

    

    <?php include'include/footer.php'?>

  <!--   Core JS Files   -->
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/popper.min.js" type="text/javascript"></script>
  <script src="js/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="js/moment.min.js"></script>
  <!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
  <script src="js/bootstrap-datetimepicker.js" type="text/javascript"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="js/nouislider.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="js/material-kit.js?v=2.0.7" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      materialKit.initFormExtendedDatetimepickers();

      // Sliders Init
      materialKit.initSliders();
    });


    function scrollToDownload() {
      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }
  </script>
</body>

</html>